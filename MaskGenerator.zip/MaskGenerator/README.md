pip install -r requirements.txt
```

2. Run the application:
```bash
streamlit run main.py
```

The app will be available at http://localhost:5000


## Estrutura do Projeto
```
.
├── main.py             # Aplicação principal
├── generator.py        # Gerador de texto
├── templates.py        # Templates de texto
├── styles.py          # Estilos da interface
├── export_utils.py    # Funções de exportação
└── .streamlit/        # Configurações do Streamlit
    └── config.toml    # Configuração do servidor